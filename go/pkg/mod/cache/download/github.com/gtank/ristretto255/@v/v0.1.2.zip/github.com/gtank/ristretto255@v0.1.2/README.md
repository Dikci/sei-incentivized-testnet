# ristretto255

[![GoDoc](https://godoc.org/github.com/gtank/ristretto255?status.svg)](https://godoc.org/github.com/gtank/ristretto255)

Package ristretto255 implements [draft-hdevalence-cfrg-ristretto-01](https://tools.ietf.org/html/draft-hdevalence-cfrg-ristretto-01).
