# Gateway

This repo contains a JSON marshaler suitable for use with the gRPC-Gateway
when using `gogo/protobuf` types.

## License

95% of the code is copied from the gRPC-Gateway project, so their license applies.
