package iface

type Msg interface {
	SomeMethod() string
}
