package enumdeclall

type MyEnum int32

const (
	A MyEnum = iota
	B MyEnum = iota
)
