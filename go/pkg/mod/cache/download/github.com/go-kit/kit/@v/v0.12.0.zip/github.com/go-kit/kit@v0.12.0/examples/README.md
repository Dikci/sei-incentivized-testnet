# Examples

Examples have been relocated to a separate repository: https://github.com/go-kit/examples
