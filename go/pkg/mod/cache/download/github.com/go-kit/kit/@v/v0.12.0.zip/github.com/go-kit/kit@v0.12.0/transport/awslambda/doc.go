// Package awslambda provides an AWS Lambda transport layer.
package awslambda
