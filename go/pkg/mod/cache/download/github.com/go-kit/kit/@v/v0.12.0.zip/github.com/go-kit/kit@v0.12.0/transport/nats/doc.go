// Package nats provides a NATS transport.
package nats
