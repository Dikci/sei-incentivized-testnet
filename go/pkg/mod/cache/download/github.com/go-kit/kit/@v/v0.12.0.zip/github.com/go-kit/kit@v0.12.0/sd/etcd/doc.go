// Package etcd provides an Instancer and Registrar implementation for etcd. If
// you use etcd as your service discovery system, this package will help you
// implement the registration and client-side load balancing patterns.
package etcd
