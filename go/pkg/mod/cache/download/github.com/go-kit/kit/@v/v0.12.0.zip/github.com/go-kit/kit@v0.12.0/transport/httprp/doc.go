// Package httprp provides an HTTP reverse-proxy transport. HTTP handlers that
// need to proxy requests to another HTTP service can do so with this package by
// specifying the URL to forward the request to.
package httprp
