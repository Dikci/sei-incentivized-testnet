# Examples

This folder demonstrates how to write a Rosetta server and how
to use either the Client package or Fetcher package to communicate
with that server.

## Steps
1. Run `make server`
2. Run `make client` (in a new terminal window)
2. Run `make fetcher` (in a new terminal window)
