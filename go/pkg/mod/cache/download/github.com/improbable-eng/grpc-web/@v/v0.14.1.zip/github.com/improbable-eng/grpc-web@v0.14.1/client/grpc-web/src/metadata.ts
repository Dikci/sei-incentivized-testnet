import {BrowserHeaders} from "browser-headers";

export {BrowserHeaders as Metadata};
