// These must match the hosts configured in .circleci/config.yml
export const testHost = "testhost";
export const corsHost = "corshost";
