// +build tools

package tools

import (
	_ "github.com/golang/protobuf/protoc-gen-go"
)
