export default function detach(cb: () => void) {
  cb();
}
