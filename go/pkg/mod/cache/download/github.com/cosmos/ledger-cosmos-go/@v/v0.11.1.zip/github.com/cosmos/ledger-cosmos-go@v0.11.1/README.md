# ledger-cosmos-go

[![CircleCI](https://circleci.com/gh/ZondaX/ledger-cosmos-go.svg?style=svg)](https://circleci.com/gh/ZondaX/ledger-cosmos-go)
[![Build status](https://ci.appveyor.com/api/projects/status/ovpfx35t289n3403?svg=true)](https://ci.appveyor.com/project/zondax/ledger-cosmos-go)

This project is work in progress. Some aspects are subject to change.

# Get source
Apart from cloning, be sure you install dep dependency management tool
https://github.com/golang/dep
