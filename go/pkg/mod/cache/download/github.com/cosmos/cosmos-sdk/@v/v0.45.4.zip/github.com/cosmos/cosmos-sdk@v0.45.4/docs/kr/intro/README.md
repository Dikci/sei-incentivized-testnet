<!--
order: false
parent:
  order: 1
-->

# 소개

이 폴더에는 Cosmos-SDK에 대한 소개 자료가 포함되어 있습니다.

1. [SDK 소개](./overview.md)
2. [애플리케이션 특화 블록체인](./why-app-specific.md)
3. [SDK 애플리케이션의 아키텍쳐](./sdk-app-architecture.md)
4. [코스모스 SDK 디자인 소개](./sdk-design.md)

해당 기본 자료를 읽으신 후 [basics](../basics/README.md) 폴더에 있는 자료를 읽어보시는 것을 추천드립니다.
