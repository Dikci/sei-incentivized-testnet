TODO

The reserve pool is the pool of collected funds for use by governance taken via the `CommunityTax`.
Currently with the SDK, tokens collected by the CommunityTax are accounted for but unspendable.
