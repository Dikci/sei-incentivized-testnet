package version

import (
	"github.com/tendermint/tendermint/version"
)

// TODO: eliminate this after some version refactor

const Version = version.ABCIVersion
