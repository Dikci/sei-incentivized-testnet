# Remote Cluster with Terraform and Ansible

See the [docs](https://docs.tendermint.com/master/networks/terraform-and-ansible.html).
