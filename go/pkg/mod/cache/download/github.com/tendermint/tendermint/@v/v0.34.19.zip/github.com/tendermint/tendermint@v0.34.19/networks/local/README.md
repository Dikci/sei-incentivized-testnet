# Local Cluster with Docker Compose

See the [docs](https://docs.tendermint.com/master/networks/docker-compose.html).
