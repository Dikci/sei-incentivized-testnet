---
order: 9
---

# RPC

The RPC documentation is hosted here:

- [https://docs.tendermint.com/master/rpc/](https://docs.tendermint.com/master/rpc/)

To update the documentation, edit the relevant `godoc` comments in the [rpc/core directory](https://github.com/tendermint/tendermint/blob/v0.34.x/rpc/core).
